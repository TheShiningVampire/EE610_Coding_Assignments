-To install the required packages use the following command
pip install -r requirements.txt

-To run the program and see the GUI interface, use the following command
python GUI.py